Investicijų dashboard. Paleidimas: pip install -r requirements.txt, tada streamlit run app.py
