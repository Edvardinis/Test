import streamlit as st
import yfinance as yf
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
from datetime import datetime, timezone

st.set_page_config(page_title="Investicijų terminalas", page_icon="📈", layout="wide")
st.title("📈 Asmeninis rinkų terminalas")
st.caption("Kainų stebėjimas, techninė analizė ir naujienos. Duomenys iš Yahoo Finance; gali vėluoti ir nėra brokerio kotiruotės.")

TICKERS = {
    "Auksas (GC=F)": "GC=F",
    "Gamtinės dujos (NG=F)": "NG=F",
    "WTI nafta (CL=F)": "CL=F",
    "Sidabras (SI=F)": "SI=F",
    "Bitcoin (BTC-USD)": "BTC-USD",
    "Quant (QNT-USD)": "QNT-USD",
    "Intel (INTC)": "INTC",
    "Netflix (NFLX)": "NFLX",
    "S&P 500 ( ^GSPC)": "^GSPC",
    "Nasdaq 100 ( ^NDX)": "^NDX",
    "EUR/USD": "EURUSD=X",
    "GBP/USD": "GBPUSD=X",
    "USD/JPY": "USDJPY=X",
    "AUD/USD": "AUDUSD=X",
    "USD/CAD": "USDCAD=X",
}

PERIODS = {"1 savaitė": "5d", "1 mėn.": "1mo", "3 mėn.": "3mo", "6 mėn.": "6mo", "1 metai": "1y", "Nuo metų pradžios": "ytd", "2 metai": "2y"}
INTERVALS = {"15 min.": "15m", "1 val.": "60m", "4 val. (dienos duomenų aproksimacija)": "1d", "1 diena": "1d", "1 savaitė": "1wk"}

with st.sidebar:
    st.header("Valdymas")
    selected_label = st.selectbox("Pagrindinis aktyvas", list(TICKERS.keys()), index=0)
    symbol = TICKERS[selected_label]
    period_label = st.selectbox("Laikotarpis", list(PERIODS.keys()), index=2)
    interval_label = st.selectbox("Žvakių intervalas", list(INTERVALS.keys()), index=3)
    show_ema = st.checkbox("EMA 20 / 50", True)
    show_bollinger = st.checkbox("Bollinger juostos", False)
    show_volume = st.checkbox("Apimtis", True)
    st.caption("15 min. ir 1 val. duomenų prieinamumas priklauso nuo Yahoo Finance istorijos ribojimų.")
    if st.button("🔄 Atnaujinti duomenis", use_container_width=True):
        st.cache_data.clear()

@st.cache_data(ttl=300, show_spinner=False)
def load_history(ticker, period, interval):
    df = yf.download(ticker, period=period, interval=interval, auto_adjust=False, progress=False, threads=False)
    if df is None or df.empty:
        return pd.DataFrame()
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    df = df.loc[:, ~df.columns.duplicated()].copy()
    for col in ["Open", "High", "Low", "Close", "Volume"]:
        if col not in df.columns:
            df[col] = np.nan
    df = df.dropna(subset=["Close"])
    df["EMA20"] = df["Close"].ewm(span=20, adjust=False).mean()
    df["EMA50"] = df["Close"].ewm(span=50, adjust=False).mean()
    delta = df["Close"].diff()
    gain = delta.clip(lower=0).ewm(alpha=1/14, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/14, adjust=False).mean()
    rs = gain / loss.replace(0, np.nan)
    df["RSI14"] = 100 - (100 / (1 + rs))
    ema12 = df["Close"].ewm(span=12, adjust=False).mean()
    ema26 = df["Close"].ewm(span=26, adjust=False).mean()
    df["MACD"] = ema12 - ema26
    df["MACD_signal"] = df["MACD"].ewm(span=9, adjust=False).mean()
    df["BB_mid"] = df["Close"].rolling(20).mean()
    std = df["Close"].rolling(20).std()
    df["BB_upper"] = df["BB_mid"] + 2 * std
    df["BB_lower"] = df["BB_mid"] - 2 * std
    return df

@st.cache_data(ttl=900, show_spinner=False)
def load_news(ticker):
    try:
        raw = yf.Ticker(ticker).news or []
        items = []
        for item in raw[:12]:
            content = item.get("content", item)
            title = content.get("title") or item.get("title") or "Be pavadinimo"
            publisher = content.get("provider", {}).get("displayName") or item.get("publisher") or "Šaltinis nenurodytas"
            link = content.get("canonicalUrl", {}).get("url") or item.get("link") or ""
            pubdate = content.get("pubDate") or item.get("providerPublishTime")
            if isinstance(pubdate, (int, float)):
                dt = datetime.fromtimestamp(pubdate, tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
            else:
                dt = str(pubdate or "")
            items.append({"title": title, "publisher": publisher, "link": link, "date": dt})
        return items
    except Exception:
        return []

df = load_history(symbol, PERIODS[period_label], INTERVALS[interval_label])
if df.empty:
    st.error("Duomenų gauti nepavyko. Pabandykite kitą intervalą arba laikotarpį.")
    st.stop()

close = float(df["Close"].iloc[-1])
prev = float(df["Close"].iloc[-2]) if len(df) > 1 else close
change_pct = ((close / prev) - 1) * 100 if prev else 0
latest = df.iloc[-1]
c1, c2, c3, c4, c5 = st.columns(5)
c1.metric("Paskutinė kaina", f"{close:,.4f}", f"{change_pct:+.2f}%")
c2.metric("Peržiūrėto laikotarpio aukščiausia", f"{df['High'].max():,.4f}")
c3.metric("Peržiūrėto laikotarpio žemiausia", f"{df['Low'].min():,.4f}")
rsi = latest["RSI14"]
c4.metric("RSI (14)", "—" if pd.isna(rsi) else f"{rsi:.1f}", "Perpirkta" if pd.notna(rsi) and rsi >= 70 else ("Perparduota" if pd.notna(rsi) and rsi <= 30 else "Neutrali zona"))
trend = "EMA20 > EMA50" if latest["EMA20"] > latest["EMA50"] else "EMA20 < EMA50"
c5.metric("EMA tendencija", trend)

st.subheader(f"🕯️ {selected_label} — kainų grafikas")
rows = 2 if show_volume else 1
heights = [0.78, 0.22] if show_volume else [1]
fig = make_subplots(rows=rows, cols=1, shared_xaxes=True, vertical_spacing=0.04, row_heights=heights, specs=[[{"secondary_y": False}], [{"secondary_y": False}]] if show_volume else [[{"secondary_y": False}]])
fig.add_trace(go.Candlestick(x=df.index, open=df["Open"], high=df["High"], low=df["Low"], close=df["Close"], name="Žvakės"), row=1, col=1)
if show_ema:
    fig.add_trace(go.Scatter(x=df.index, y=df["EMA20"], name="EMA 20", line=dict(width=1.3)), row=1, col=1)
    fig.add_trace(go.Scatter(x=df.index, y=df["EMA50"], name="EMA 50", line=dict(width=1.3)), row=1, col=1)
if show_bollinger:
    fig.add_trace(go.Scatter(x=df.index, y=df["BB_upper"], name="BB viršus", line=dict(width=1, dash="dot")), row=1, col=1)
    fig.add_trace(go.Scatter(x=df.index, y=df["BB_lower"], name="BB apačia", line=dict(width=1, dash="dot"), fill="tonexty"), row=1, col=1)
if show_volume:
    fig.add_trace(go.Bar(x=df.index, y=df["Volume"], name="Apimtis", opacity=0.45), row=2, col=1)
fig.update_layout(template="plotly_dark", height=650 if show_volume else 540, margin=dict(l=10,r=10,t=25,b=10), xaxis_rangeslider_visible=False, legend=dict(orientation="h", y=1.02, x=0))
fig.update_yaxes(title_text="Kaina", row=1, col=1)
if show_volume:
    fig.update_yaxes(title_text="Apimtis", row=2, col=1)
st.plotly_chart(fig, use_container_width=True)

left, right = st.columns(2)
with left:
    st.subheader("📐 Techniniai indikatoriai")
    ind = df[["Close", "EMA20", "EMA50", "RSI14", "MACD", "MACD_signal"]].tail(8).copy()
    ind.columns = ["Uždarymo kaina", "EMA 20", "EMA 50", "RSI 14", "MACD", "MACD signal"]
    st.dataframe(ind.round(4), use_container_width=True)
    st.caption("RSI > 70 dažnai vadinamas perpirkta zona, RSI < 30 — perparduota. Tai nėra savaiminis pirkimo ar pardavimo signalas.")
with right:
    st.subheader("🧭 Techninės būklės santrauka")
    bullets = []
    bullets.append("Kaina virš EMA 20." if close > latest["EMA20"] else "Kaina žemiau EMA 20.")
    bullets.append("EMA 20 virš EMA 50 — trumpesnio periodo kryptis stipresnė." if latest["EMA20"] > latest["EMA50"] else "EMA 20 žemiau EMA 50 — trumpesnio periodo kryptis silpnesnė.")
    if pd.notna(rsi):
        bullets.append("RSI rodo perpirkimo zoną." if rsi >= 70 else ("RSI rodo perpardavimo zoną." if rsi <= 30 else "RSI yra tarp 30 ir 70."))
    bullets.append("MACD virš signalo linijos." if latest["MACD"] > latest["MACD_signal"] else "MACD žemiau signalo linijos.")
    for b in bullets:
        st.write("• " + b)
    st.info("Santrauka aprašo tik pasirinktus techninius rodiklius. Ji neįvertina sandorio kaštų, brokerio spread'o, fundamentinių įvykių ar tavo pozicijos maržos.")

st.divider()
st.subheader("📰 Naujausios su aktyvu susijusios naujienos")
news = load_news(symbol)
if news:
    for item in news:
        st.markdown(f"**[{item['title']}]({item['link']})**" if item["link"] else f"**{item['title']}**")
        st.caption(f"{item['publisher']} · {item['date']}")
else:
    st.write("Šiuo metu naujienų srauto gauti nepavyko. Yahoo Finance naujienų prieinamumas skiriasi pagal simbolį.")
st.caption("Naujienų antraštės ir nuorodos pateikiamos iš Yahoo Finance / jų tiekėjų. Antraštė nėra patvirtintas kainos pokyčio paaiškinimas.")

st.divider()
st.subheader("👁️ Greita stebimų aktyvų lentelė")
watch_period = PERIODS["1 mėn."]
watch_rows = []
with st.spinner("Gaunami stebimų aktyvų duomenys..."):
    for label, ticker in TICKERS.items():
        try:
            q = yf.download(ticker, period=watch_period, interval="1d", progress=False, threads=False)
            if q is None or q.empty:
                continue
            if isinstance(q.columns, pd.MultiIndex):
                q.columns = q.columns.get_level_values(0)
            q = q.dropna(subset=["Close"])
            if q.empty:
                continue
            last = float(q["Close"].iloc[-1])
            prior = float(q["Close"].iloc[-2]) if len(q) > 1 else last
            watch_rows.append({"Aktyvas": label, "Kaina": last, "1 d. pokytis %": (last/prior-1)*100 if prior else 0, "1 mėn. max": float(q["High"].max()), "1 mėn. min": float(q["Low"].min())})
        except Exception:
            pass
if watch_rows:
    table = pd.DataFrame(watch_rows)
    st.dataframe(table.style.format({"Kaina":"{:,.4f}", "1 d. pokytis %":"{:+.2f}%", "1 mėn. max":"{:,.4f}", "1 mėn. min":"{:,.4f}"}), use_container_width=True, hide_index=True)
else:
    st.warning("Stebimų aktyvų lentelės duomenų šiuo metu nėra.")

st.caption(f"Atnaujinta pagal užklausą: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} · Cache: kainos 5 min., naujienos 15 min.")
st.warning("Tai analitinis įrankis, ne finansinė rekomendacija. Futures simboliai (pvz., GC=F, CL=F, NG=F) nėra tas pats, kas brokerio XAUUSD/XTIUSD/XNGUSD CFD; kainos ir prekybos valandos gali skirtis.")
